#!/usr/bin/python
# -*- coding: utf-8 -*-



# ------- IMPORT LOCAL DEPENDENCIES  -------
from app import app


LOGIN_MESSAGE = "You must be logged in to access this page."
LOGIN_MESSAGE_CATEGORY = "info"
LOGIN_CONTROLLER = "auth_page.login"




