#!/usr/bin/python
# -*- coding: utf-8 -*-

# ------- IMPORT LOCAL DEPENDENCIES  -------
from . import login_form, registration_form, settings_form