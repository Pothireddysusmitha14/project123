#!/usr/bin/python
# -*- coding: utf-8 -*-

# ------- IMPORT DEPENDENCIES ------- 


# ------- IMPORT LOCAL DEPENDENCIES  -------
# from app import app


# PAYPAL CONFIG
PAYPAL_MODE = "sandbox" # sandbox or live
PAYPAL_CLIENT_ID = "ATcNxfmVFttFZG3v6mnrjkdfjgkfGG9RzZqBZxxxxxxxxxxxxxxxxxxxxxxx"
PAYPAL_CLIENT_SECRET = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"


# app.config['PAYPAL_MODE'] = "sandbox" # sandbox or live
# app.config['PAYPAL_CLIENT_ID'] = "ATcNxfmVFttFZG3v6mnrjkdfjgkfGG9RzZqBZxxxxxxxxxxxxxxxxxxxxxxx"
# app.config['PAYPAL_CLIENT_SECRET'] = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"