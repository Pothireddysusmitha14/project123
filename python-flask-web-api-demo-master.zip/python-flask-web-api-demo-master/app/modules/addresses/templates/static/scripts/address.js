$(document).ready(function () {
    // Todo
})
