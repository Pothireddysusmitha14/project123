#!/usr/bin/python
# -*- coding: utf-8 -*-

# ------- IMPORT DEPENDENCIES ------- 


# ------- IMPORT LOCAL DEPENDENCIES  -------
# from app import app




GOOGLE_MAP_API_KEY = ''
# app.config['GOOGLE_MAP_API_KEY'] = GOOGLE_MAP_API_KEY